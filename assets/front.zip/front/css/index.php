<?php
echo "No direct script access allowed";
?>
